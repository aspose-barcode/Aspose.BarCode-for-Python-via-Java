var classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "__eq__", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#aa70abd1170d16c55bcd80d48f1e6d26e", null ],
    [ "__hash__", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#ae27a7920f84bb5c804c9615ef57874e5", null ],
    [ "__str__", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getDotCodeIsReaderInitialization", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#a6207f566baad7211e097abc33b24977d", null ],
    [ "getDotCodeStructuredAppendModeBarcodeId", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#ace51796925c25fda48824aa57ccdc9e3", null ],
    [ "getDotCodeStructuredAppendModeBarcodesCount", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#a57b1b596a84d9066d4c42d6f53826af3", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_dot_code_extended_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ]
];