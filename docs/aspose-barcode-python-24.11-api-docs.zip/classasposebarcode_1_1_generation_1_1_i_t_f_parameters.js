var classasposebarcode_1_1_generation_1_1_i_t_f_parameters =
[
    [ "__init__", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a7fe5014f8f7b6b7ef8c90b889014d2ea", null ],
    [ "__str__", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getItfBorderThickness", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#ad929079715c477e2d85e43c3bf87e059", null ],
    [ "getItfBorderType", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a9a7161aa8bc58c1285e421b09380ce04", null ],
    [ "getQuietZoneCoef", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a3a7210f19e38c43c7097cc8cb8a40de5", null ],
    [ "init", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "setItfBorderThickness", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a70b56dae63520b2c9d7c23a82684cc14", null ],
    [ "setItfBorderType", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a7e1496f3f94d7fb35ca257df0c1ea2ef", null ],
    [ "setQuietZoneCoef", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a55378442ae82eef91d60af0bb7566cb8", null ],
    [ "itfBorderThickness", "classasposebarcode_1_1_generation_1_1_i_t_f_parameters.html#a0d566be9df8f293293c906cc96e3b409", null ]
];