var classasposebarcode_1_1_recognition_1_1_bar_code_reader =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#aa19c214b792421d3172c6f2a29b602a3", null ],
    [ "abort", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#af7aacc6280ffb78d9fa772e709620e53", null ],
    [ "containsAny", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a7577aedea7057d768100c72b02380aee", null ],
    [ "exportToXml", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a30aa7284e5be843d85a75fdc45a2bdf4", null ],
    [ "getBarCodeDecodeType", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a7a73cd272b5349ec6ff134b2400f7e20", null ],
    [ "getBarcodeSettings", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a158928737d438cbc0ba265e2cc4f1c61", null ],
    [ "getFoundBarCodes", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#abde68ad642b912c7b351491f8296e921", null ],
    [ "getFoundCount", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a3f4375c011ad69a3d5f20bf29555c9e0", null ],
    [ "getQualitySettings", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a5cb01c241e77ef147f94f7678d36a8ea", null ],
    [ "getTimeout", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a3fd5cbd8e30fe1b15055c451c28bd6ad", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "readBarCodes", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a03a263a8a756b84039e09813df240260", null ],
    [ "setBarCodeImage", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a159e8f86232da57a949517250a7687d5", null ],
    [ "setBarCodeReadType", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#ac252448ec7dca40d0d325d3ef70d55f3", null ],
    [ "setQualitySettings", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a18edfe0a8b565266c91dafb6775c2a33", null ],
    [ "setTimeout", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a2737f28b4ced9274ba40b5c3fdc27cca", null ],
    [ "barcodeSettings", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#affe1b6ed9d59dc50b4c358651ac89204", null ],
    [ "qualitySettings", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#aadbe93187020929483564eda87566a15", null ],
    [ "recognizedResults", "classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#a94b95b9ae41596001efd1aae5abaafa4", null ]
];