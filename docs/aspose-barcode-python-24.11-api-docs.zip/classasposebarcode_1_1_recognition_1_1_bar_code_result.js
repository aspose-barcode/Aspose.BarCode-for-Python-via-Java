var classasposebarcode_1_1_recognition_1_1_bar_code_result =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "__eq__", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#ad05d6e089a7ca88e8f99aa25cf591ad7", null ],
    [ "__hash__", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#ae27a7920f84bb5c804c9615ef57874e5", null ],
    [ "__str__", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "deepClone", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a7767ea96e5cf2882a404f0eaa5f19f02", null ],
    [ "getCodeBytes", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a45d1d5dfb19bd834eeb4a5bd8a7bb198", null ],
    [ "getCodeText", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#acd3162021f458107e39c4a705323cf5e", null ],
    [ "getCodeType", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a6c11fe282e0ed557961971ecb21459e6", null ],
    [ "getCodeTypeName", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#af0de26b056dd8e8550089d89a33b1e48", null ],
    [ "getConfidence", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a1e767134984aec920773c58c1debd065", null ],
    [ "getExtended", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a75ad224aeb83fc4db35562f5d8935d9e", null ],
    [ "getReadingQuality", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a23d829b22ccd6cbe177b2d5987bec6a0", null ],
    [ "getRegion", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a1eec188cebd31a83bc636b947b9854b4", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "extended", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a27233dfd57a1c70691a51987915b4616", null ],
    [ "region", "classasposebarcode_1_1_recognition_1_1_bar_code_result.html#a1b9edddb3735d131c67e9e824f07c402", null ]
];