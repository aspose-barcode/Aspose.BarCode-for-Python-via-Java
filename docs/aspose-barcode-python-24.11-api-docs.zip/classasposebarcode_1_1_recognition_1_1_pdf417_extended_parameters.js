var classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "__eq__", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a08bf068bf4f21d21e0755bfdce5bc405", null ],
    [ "__hash__", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#ae27a7920f84bb5c804c9615ef57874e5", null ],
    [ "__str__", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getMacroPdf417Addressee", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#ac0af5b744676de1045770f18422655e6", null ],
    [ "getMacroPdf417Checksum", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a4eab52bfca0a6d4c290aca64bf4fb3e4", null ],
    [ "getMacroPdf417FileID", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#adbd2dbabc6156747fa855dfd065536ef", null ],
    [ "getMacroPdf417FileName", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a0012ab53ef9740c9c529c37dcd9559de", null ],
    [ "getMacroPdf417FileSize", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a1400a1b3a68632784a23e5603f4b0567", null ],
    [ "getMacroPdf417SegmentID", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a01796ca638d7df9543305e2c82495e3b", null ],
    [ "getMacroPdf417SegmentsCount", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#ac853c99671311f4827b66dd8f09e49f6", null ],
    [ "getMacroPdf417Sender", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#afd390f509794ec9963d33c24fa3f8ad6", null ],
    [ "getMacroPdf417Terminator", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a69ebcc2a497ce4d53beb615bdae9f87c", null ],
    [ "getMacroPdf417TimeStamp", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#abef976ca90fd5aaeae6d1de0f67d5448", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "isCode128Emulation", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#aa51522de14b52b19312ceac5c9967d27", null ],
    [ "isLinked", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#ace286e7593ad711afce35c6e797a6262", null ],
    [ "isReaderInitialization", "classasposebarcode_1_1_recognition_1_1_pdf417_extended_parameters.html#a65f79a9181dda4f0966014cd149e7645", null ]
];