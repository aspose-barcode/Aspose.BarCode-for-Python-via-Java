var classasposebarcode_1_1_recognition_1_1_quality_settings =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "getAllowIncorrectBarcodes", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a0d264c15942943d89879cdea4f14ba08", null ],
    [ "getBarcodeQuality", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#ace1631c0649a63a038d4311931b8f1f7", null ],
    [ "getComplexBackground", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a17d6b153833bf8cacb636831d425eb1f", null ],
    [ "getDeconvolution", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#abcb29ed5004f83d3f90131656228a62c", null ],
    [ "getInverseImage", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a4be69431008e00cd37cd97e1f4ca8459", null ],
    [ "getMinimalXDimension", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a2cb2eb3897bd3239ad92f0c95cc6371c", null ],
    [ "getXDimension", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#abcef6c79f260dd70e0f3ab8c954bc924", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "setAllowIncorrectBarcodes", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#ae8c5c58965b613c3455ca79ac3178dfe", null ],
    [ "setBarcodeQuality", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a43b766d402f382732d60deb78c13c302", null ],
    [ "setComplexBackground", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a256932a1914e50b989ea05c139457582", null ],
    [ "setDeconvolution", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a203c16091aae3d4a53efa0a23c91a924", null ],
    [ "setInverseImage", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a69e658f174e39e3027de1761cfd9af03", null ],
    [ "setMinimalXDimension", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a6434039b4b314c95984965f96e8c152b", null ],
    [ "setXDimension", "classasposebarcode_1_1_recognition_1_1_quality_settings.html#a6fa8af06199527942394fa9d3da6e4d2", null ]
];