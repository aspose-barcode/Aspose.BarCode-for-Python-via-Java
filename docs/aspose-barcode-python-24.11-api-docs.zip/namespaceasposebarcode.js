var namespaceasposebarcode =
[
    [ "Assist", "namespaceasposebarcode_1_1_assist.html", "namespaceasposebarcode_1_1_assist" ],
    [ "ComplexBarcode", "namespaceasposebarcode_1_1_complex_barcode.html", "namespaceasposebarcode_1_1_complex_barcode" ],
    [ "Generation", "namespaceasposebarcode_1_1_generation.html", "namespaceasposebarcode_1_1_generation" ],
    [ "Recognition", "namespaceasposebarcode_1_1_recognition.html", "namespaceasposebarcode_1_1_recognition" ],
    [ "__asposebarcode_dir__", "namespaceasposebarcode.html#a3ca5d9a825361f9e613bb0a0028ed560", null ],
    [ "__barcode_jar_path__", "namespaceasposebarcode.html#ada3d220d5e01fe3d24c0e47a8f8844c2", null ]
];