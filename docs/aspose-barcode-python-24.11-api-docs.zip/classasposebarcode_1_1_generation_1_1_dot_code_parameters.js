var classasposebarcode_1_1_generation_1_1_dot_code_parameters =
[
    [ "__init__", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a7fe5014f8f7b6b7ef8c90b889014d2ea", null ],
    [ "__str__", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getAspectRatio", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a9f5539c8b9ab82fbad7a713529f6484f", null ],
    [ "getColumns", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#aac0bd0b2987f603f6e3a3c13b83d86be", null ],
    [ "getDotCodeEncodeMode", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#ac3fd5587b538f87e3ea71e1ad5088904", null ],
    [ "getDotCodeStructuredAppendModeBarcodeId", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#ace51796925c25fda48824aa57ccdc9e3", null ],
    [ "getDotCodeStructuredAppendModeBarcodesCount", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a57b1b596a84d9066d4c42d6f53826af3", null ],
    [ "getECIEncoding", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a25071d8af5ab8dd1c25e8b7b6539f076", null ],
    [ "getRows", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a9c2727425beec9ac08e24baaa6b96dc5", null ],
    [ "init", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "isReaderInitialization", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a65f79a9181dda4f0966014cd149e7645", null ],
    [ "setAspectRatio", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#abfd059a0ff346d0a00c5fd08f80dfd06", null ],
    [ "setColumns", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a7980a74eb92a0c172f6813e37617eac7", null ],
    [ "setDotCodeEncodeMode", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#adba0c83fcfc5195c002a5d4cfecd182f", null ],
    [ "setDotCodeStructuredAppendModeBarcodeId", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a4b76c9b3d936c5d1e42e25b8be23eaf6", null ],
    [ "setDotCodeStructuredAppendModeBarcodesCount", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a5e5e36961543dfbe7ef1603f3dab8374", null ],
    [ "setECIEncoding", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a7a855a939e83429b8ddef8ce38120817", null ],
    [ "setReaderInitialization", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a43d4b7d656f057c03ff535418dc8f980", null ],
    [ "setRows", "classasposebarcode_1_1_generation_1_1_dot_code_parameters.html#a1d010f3dab9d2d85bc100975b5a0da40", null ]
];