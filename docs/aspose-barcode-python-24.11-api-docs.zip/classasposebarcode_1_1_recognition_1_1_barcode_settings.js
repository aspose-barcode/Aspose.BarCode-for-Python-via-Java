var classasposebarcode_1_1_recognition_1_1_barcode_settings =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "getAustraliaPost", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#a669f4d41b813947a27b5f75c8f6399c7", null ],
    [ "getChecksumValidation", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#ab8ba0bf3f0376f384aeb5fb68fb29902", null ],
    [ "getDetectEncoding", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#a28e7b2246134d25b89c49caabff4b79e", null ],
    [ "getStripFNC", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#a0f06995e7ae84755ada601dc503bc3e0", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "setChecksumValidation", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#aed6fd91f68e38dcec5f69477b6b6b862", null ],
    [ "setDetectEncoding", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#aa05bed9a5d058c4f403084ba66e7c044", null ],
    [ "setStripFNC", "classasposebarcode_1_1_recognition_1_1_barcode_settings.html#a26f56e4767e0649f53023e80ce726c0e", null ]
];