var classasposebarcode_1_1_recognition_1_1_australia_post_settings =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_australia_post_settings.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "getCustomerInformationInterpretingType", "classasposebarcode_1_1_recognition_1_1_australia_post_settings.html#ae01186ddb7c28ea6efc4400b28001ad8", null ],
    [ "getIgnoreEndingFillingPatternsForCTable", "classasposebarcode_1_1_recognition_1_1_australia_post_settings.html#a50cc16c348f67780549c50cda27d99d1", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_australia_post_settings.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "setCustomerInformationInterpretingType", "classasposebarcode_1_1_recognition_1_1_australia_post_settings.html#a39f68c00b6bb7c8faadfb20abcb6d8e2", null ],
    [ "setIgnoreEndingFillingPatternsForCTable", "classasposebarcode_1_1_recognition_1_1_australia_post_settings.html#a682d99ab0b0731b8abaf70d138195e34", null ]
];