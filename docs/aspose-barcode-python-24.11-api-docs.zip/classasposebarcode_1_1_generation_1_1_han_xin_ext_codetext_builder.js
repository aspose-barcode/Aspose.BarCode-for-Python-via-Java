var classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder =
[
    [ "__init__", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#abc1b785959b47505de72feabab160402", null ],
    [ "addAuto", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a642a32bcd23d58ab4cd69acf87cf782f", null ],
    [ "addBinary", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a49b0c2f2801ca0a2293bf331a54ff8f2", null ],
    [ "addCommonChineseRegionOne", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a2fb89ec9069e55db25ea8856b420a38c", null ],
    [ "addCommonChineseRegionTwo", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a5243bab2d82c0cad34a79c4297102ed7", null ],
    [ "addECI", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a9a97926ccb293d2799dafb18b9a8e44d", null ],
    [ "addGB18030FourByte", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a0a62fb284c3a0ed031cb535811910009", null ],
    [ "addGB18030TwoByte", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a1b4f49b4bbb8625e93dd907a9ebe53ef", null ],
    [ "addGS1", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#acc44966c6c445ecc96194bc5e22a827b", null ],
    [ "addNumeric", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#aea501950bb3f94054462c86bb67f34e2", null ],
    [ "addText", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#abc576418cee204b199dc8890e63c5f97", null ],
    [ "addUnicode", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a9fd3085e6d6e9400bf54516ccb9ac9c7", null ],
    [ "addURI", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#ace7659f861d8d26208c232f10741d846", null ],
    [ "getExtendedCodetext", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#ad710a1ca70281f79c8a548f920c3fcd2", null ],
    [ "init", "classasposebarcode_1_1_generation_1_1_han_xin_ext_codetext_builder.html#a31c724fc61abf1bd6de9315933c374f0", null ]
];