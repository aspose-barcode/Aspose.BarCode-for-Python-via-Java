var classasposebarcode_1_1_generation_1_1_patch_code_parameters =
[
    [ "__init__", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#a7fe5014f8f7b6b7ef8c90b889014d2ea", null ],
    [ "__str__", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getExtraBarcodeText", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#a84b56500a236e3cab955ed2959d191ea", null ],
    [ "getPatchFormat", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#a6c73e4ed89d1e557f68dbfea70ca03be", null ],
    [ "init", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "setExtraBarcodeText", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#a5880bc3d9971f88e4cf8e68ba128c140", null ],
    [ "setPatchFormat", "classasposebarcode_1_1_generation_1_1_patch_code_parameters.html#a2dc0131f4e7d7dc78f9627fe4abc0636", null ]
];