var classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "__eq__", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#a646f68c8b9e201fce510737d058c4b49", null ],
    [ "__hash__", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#ae27a7920f84bb5c804c9615ef57874e5", null ],
    [ "__str__", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getAngle", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#af9df1dbcd45247df1d4b3d93025805b5", null ],
    [ "getPoints", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#a697927352b177c9715303879759dcf9e", null ],
    [ "getQuadrangle", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#afb7afb848277868723eee3297d4d8f0a", null ],
    [ "getRectangle", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#ada888bd81f2b3e622c541d54277b20bc", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "points", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#ab9a89211ecb71d18bbd259853fda1c54", null ],
    [ "quad", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#afed2c57e6a0b803cfd12760897b295d7", null ],
    [ "rect", "classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#aea8f6815d9a63491fc422c5572c6b3c3", null ]
];