var classasposebarcode_1_1_generation_1_1_border_parameters =
[
    [ "__init__", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "__str__", "classasposebarcode_1_1_generation_1_1_border_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getColor", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a32b505183e586590a85a20ed6f2309e4", null ],
    [ "getDashStyle", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a342ccd4887d917b7c1c44e7a93bf8278", null ],
    [ "getVisible", "classasposebarcode_1_1_generation_1_1_border_parameters.html#ae9e806e5c8eec8f8571476c630d7b66d", null ],
    [ "getWidth", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a9f2d06f5acf866b9e03afcb34e1f041d", null ],
    [ "init", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "setColor", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a698cfbf067f15f20f7b3b115026b8f95", null ],
    [ "setDashStyle", "classasposebarcode_1_1_generation_1_1_border_parameters.html#aa7e5e8d2cb637470f27ff435f9b71cfb", null ],
    [ "setVisible", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a4b9ec7f9c0be29966e59c67137e3f0b3", null ],
    [ "setWidth", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a8c9cf8ed11b8fbfa0ab56cbe73c9d031", null ],
    [ "width", "classasposebarcode_1_1_generation_1_1_border_parameters.html#a5558ace5433f9aabbf0a0ec059900d94", null ]
];