var searchData=
[
  ['qr_836',['QR',['../classasposebarcode_1_1_generation_1_1_encode_types.html#a7508433272e5601cc144d59ec53f7a22',1,'asposebarcode.Generation.EncodeTypes.QR()'],['../classasposebarcode_1_1_recognition_1_1_decode_type.html#a7508433272e5601cc144d59ec53f7a22',1,'asposebarcode.Recognition.DecodeType.QR()']]],
  ['qrbillstandardversion_837',['QrBillStandardVersion',['../classasposebarcode_1_1_complex_barcode_1_1_qr_bill_standard_version.html',1,'asposebarcode::ComplexBarcode']]],
  ['qrencodemode_838',['QREncodeMode',['../classasposebarcode_1_1_generation_1_1_q_r_encode_mode.html',1,'asposebarcode::Generation']]],
  ['qrencodetype_839',['QREncodeType',['../classasposebarcode_1_1_generation_1_1_q_r_encode_type.html',1,'asposebarcode::Generation']]],
  ['qrerrorlevel_840',['QRErrorLevel',['../classasposebarcode_1_1_generation_1_1_q_r_error_level.html',1,'asposebarcode::Generation']]],
  ['qrextcodetextbuilder_841',['QrExtCodetextBuilder',['../classasposebarcode_1_1_generation_1_1_qr_ext_codetext_builder.html',1,'asposebarcode::Generation']]],
  ['qrextendedparameters_842',['QRExtendedParameters',['../classasposebarcode_1_1_recognition_1_1_q_r_extended_parameters.html',1,'asposebarcode::Recognition']]],
  ['qrparameters_843',['QrParameters',['../classasposebarcode_1_1_generation_1_1_qr_parameters.html',1,'asposebarcode::Generation']]],
  ['qrstructuredappendparameters_844',['QrStructuredAppendParameters',['../classasposebarcode_1_1_generation_1_1_qr_structured_append_parameters.html',1,'asposebarcode::Generation']]],
  ['qrversion_845',['QRVersion',['../classasposebarcode_1_1_generation_1_1_q_r_version.html',1,'asposebarcode::Generation']]],
  ['quad_846',['quad',['../classasposebarcode_1_1_recognition_1_1_bar_code_region_parameters.html#afed2c57e6a0b803cfd12760897b295d7',1,'asposebarcode::Recognition::BarCodeRegionParameters']]],
  ['quadrangle_847',['Quadrangle',['../classasposebarcode_1_1_recognition_1_1_quadrangle.html',1,'asposebarcode::Recognition']]],
  ['qualitysettings_848',['QualitySettings',['../classasposebarcode_1_1_recognition_1_1_quality_settings.html',1,'asposebarcode::Recognition']]],
  ['qualitysettings_849',['qualitySettings',['../classasposebarcode_1_1_recognition_1_1_bar_code_reader.html#aadbe93187020929483564eda87566a15',1,'asposebarcode::Recognition::BarCodeReader']]]
];
