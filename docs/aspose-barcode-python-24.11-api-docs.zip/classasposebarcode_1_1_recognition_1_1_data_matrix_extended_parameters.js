var classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters =
[
    [ "__init__", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#a6e92a6f6c8e2304e4a3d0a5c19e98814", null ],
    [ "__eq__", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#a372f3d0401f4bf72e1375c2677a621e6", null ],
    [ "__hash__", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#ae27a7920f84bb5c804c9615ef57874e5", null ],
    [ "__str__", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#ae07f7930f92d3591c93e2381cd5be285", null ],
    [ "getStructuredAppendBarcodeId", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#afa3d9a625070150a4445115be7bf8925", null ],
    [ "getStructuredAppendBarcodesCount", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#aedede8c5ea747896bc0bea4629b91b0c", null ],
    [ "getStructuredAppendFileId", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#a997ff59cbf8b2748a01cfc6a4a69f15f", null ],
    [ "init", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#a31c724fc61abf1bd6de9315933c374f0", null ],
    [ "isReaderProgramming", "classasposebarcode_1_1_recognition_1_1_data_matrix_extended_parameters.html#a9b2d1d9598ad9dadd710c875b9b64fda", null ]
];